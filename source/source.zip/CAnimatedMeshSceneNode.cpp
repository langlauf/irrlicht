// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CAnimatedMeshSceneNode.h"
#include "IVideoDriver.h"
#include "ISceneManager.h"
#include "S3DVertex.h"
#include "os.h"
#include "CShadowVolumeSceneNode.h"
#include "SViewFrustrum.h"
#include "ICameraSceneNode.h"

namespace irr
{
namespace scene
{



//! constructor
CAnimatedMeshSceneNode::CAnimatedMeshSceneNode(IAnimatedMesh* mesh, ISceneNode* parent, ISceneManager* mgr, s32 id,
			const core::vector3df& position, const core::vector3df& rotation,	const core::vector3df& scale)
: IAnimatedMeshSceneNode(parent, mgr, id, position, rotation, scale), Mesh(mesh), 
	BeginFrameTime(0), StartFrame(0), EndFrame(0), FramesPerSecond(100),
	Shadow(0)
{
	BeginFrameTime = os::Timer::getTime();

	if (Mesh)
	{
		// get materials.

		IMesh* m = Mesh->getMesh(0,0);
		if (m)
		{
			video::SMaterial mat;
			for (s32 i=0; i<m->getMeshBufferCount(); ++i)
			{
				IMeshBuffer* mb = m->getMeshBuffer(i);
				if (mb)
					mat = mb->getMaterial();

				Materials.push_back(mat);
			}
		}

		// get start and begin time

		StartFrame = 0;
		EndFrame = Mesh->getFrameCount();

		// grab the mesh

		Mesh->grab();
	}
}



//! destructor
CAnimatedMeshSceneNode::~CAnimatedMeshSceneNode()
{
	if (Mesh)
		Mesh->drop();

	if (Shadow)
		Shadow->drop();

	for (s32 i=0; i<(s32)AttachedChilds.size(); ++i)
		AttachedChilds[i].node->drop();
}



//! sets the current frame. from now on the animation is played from this frame.
void CAnimatedMeshSceneNode::setCurrentFrame(s32 frame)
{
}


//! frame
void CAnimatedMeshSceneNode::OnPreRender()
{
	if (IsVisible)
		SceneManager->registerNodeForRendering(this);

	ISceneNode::OnPreRender();

	if (IsVisible)
		for (s32 i=0; i<(s32)AttachedChilds.size(); ++i)
			AttachedChilds[i].node->OnPreRender();
}


inline s32 CAnimatedMeshSceneNode::getFrameNr()
{
	s32 frame = 0;

	if (EndFrame - StartFrame)
		frame = StartFrame + ((s32)((os::Timer::getTime() - BeginFrameTime)
			* (FramesPerSecond/1000.0f)) % (EndFrame - StartFrame));
	else
		frame = StartFrame;

	return frame;
}



//! OnPostRender() is called just after rendering the whole scene.
void CAnimatedMeshSceneNode::OnPostRender(u32 timeMs)
{
	s32 frameNr = getFrameNr();
	s32 i;

	AnimatedRelativeTransformation = RelativeTransformation;

	if (IsVisible)
	{
		// animate this node with all animators

		core::list<ISceneNodeAnimator*>::Iterator ait = Animators.begin();
		for (; ait != Animators.end(); ++ait)
			(*ait)->animateNode(this, timeMs);

		// update absolute position
		updateAbsolutePosition();

		// change relative position of all attached childs
		if (Mesh)
		for (i=0; i<(s32)AttachedChilds.size(); ++i)
		{
			const core::matrix4* mat;
			mat = Mesh->getMatrixOfMeshPart(AttachedChilds[i].partname.c_str(), frameNr);

			core::matrix4 transform = AttachedChilds[i].transform;

			if (mat)
				transform *= (*mat);

			AttachedChilds[i].node->getRelativeTransformation() = transform;
		}

		// perform the post render process on all children
		
		core::list<ISceneNode*>::Iterator it = Children.begin();
		for (; it != Children.end(); ++it)
			(*it)->OnPostRender(timeMs);

		for (i=0; i<(s32)AttachedChilds.size(); ++i)
			AttachedChilds[i].node->OnPostRender(timeMs);
	}
}


//! renders the node.
void CAnimatedMeshSceneNode::render()
{
	video::IVideoDriver* driver = SceneManager->getVideoDriver();

	if (!Mesh || !driver)
		return;

	driver->setTransform(video::TS_WORLD, AbsoluteTransformation);

	s32 frame = getFrameNr();

	scene::IMesh* m = Mesh->getMesh(frame, 255, StartFrame, EndFrame);

	if (m)
	{
		Box = m->getBoundingBox();

		// for debug purposes only:
		//driver->setMaterial(Materials[0]);
		//driver->draw3DBox(Box);

		if (Shadow)
			Shadow->setMeshToRenderFrom(m);

		for (s32 i=0; i<m->getMeshBufferCount(); ++i)
		{
			scene::IMeshBuffer* mb = m->getMeshBuffer(i);
			
			driver->setMaterial(Materials[i]);

			switch(mb->getVertexType())
			{
			case video::EVT_STANDARD:
				driver->drawIndexedTriangleList((video::S3DVertex*)mb->getVertices(), mb->getVertexCount(), mb->getIndices(), mb->getIndexCount()/ 3);
				break;
			case video::EVT_2TCOORDS:
				driver->drawIndexedTriangleList((video::S3DVertex2TCoords*)mb->getVertices(), mb->getVertexCount(), mb->getIndices(), mb->getIndexCount()/ 3);
				break;				
			}
			
		}			
	}
	#ifdef _DEBUG
	else
		os::Warning::print("Animated Mesh returned no mesh to render.", Mesh->getDebugName());
	#endif
}



//! sets the frames between the animation is looped.
//! the default is 0 - MaximalFrameCount of the mesh.
bool CAnimatedMeshSceneNode::setFrameLoop(s32 begin, s32 end)
{
	if (!Mesh)
		return false;

	s32 frameCount = Mesh->getFrameCount();

	if (!(begin <= end && begin < frameCount && end < frameCount))
		return false;

	StartFrame = begin;
	EndFrame = end;
	BeginFrameTime = os::Timer::getTime();

	return true;
}



//! sets the speed with witch the animation is played
void CAnimatedMeshSceneNode::setAnimationSpeed(s32 framesPerSecond)
{
	FramesPerSecond = framesPerSecond;
}




//! returns the axis aligned bounding box of this node
const core::aabbox3d<f32>& CAnimatedMeshSceneNode::getBoundingBox() const
{
	return Mesh ? Mesh->getBoundingBox() : Box;
}


//! returns the material based on the zero based index i. To get the amount
//! of materials used by this scene node, use getMaterialCount().
//! This function is needed for inserting the node into the scene hirachy on a
//! optimal position for minimizing renderstate changes, but can also be used
//! to directly modify the material of a scene node.
video::SMaterial& CAnimatedMeshSceneNode::getMaterial(s32 i)
{
	if (i < 0 || i >= (s32)Materials.size())
		return ISceneNode::getMaterial(i);

	return Materials[i];
}



//! returns amount of materials used by this scene node.
s32 CAnimatedMeshSceneNode::getMaterialCount()
{
	return Materials.size();
}


//! Creates shadow volume scene node as child of this node
//! and returns a pointer to it. 
IShadowVolumeSceneNode* CAnimatedMeshSceneNode::addShadowVolumeSceneNode(s32 id)
{
	if (!SceneManager->getVideoDriver()->queryFeature(video::EK3DVDF_STENCIL_BUFFER))
		return 0;

	if (Shadow)
	{
		os::Warning::print("This node already has a shadow.");
		return 0;
	}

	Shadow = new CShadowVolumeSceneNode(this, SceneManager, -1);
	return Shadow;
}


//! Adds a child scene node which is animated by a part of the animated
//! mesh. In this way, it is for example possible to attach a weapon the
//! the left hand of an animated model.
bool CAnimatedMeshSceneNode::addChild(const c8* name, ISceneNode* child)
{
	if (!child || !name)
		return false;

	SAttachedChild c;

	// remove from current parent and move it into the special array
	child->grab();
	child->setParent(this);
	ISceneNode::removeChild(child);
	
	// add

	c.node = child;
	c.partname = name;
	c.transform = child->getRelativeTransformation();

	bool found = false;
	if (Mesh)
		 found = (Mesh->getMatrixOfMeshPart(name, 0) != 0);

	AttachedChilds.push_back(c);

	return found;
}



//! Removes a child from this scene node.
//! Implemented here, to be able to remove the shadow properly, if there is one,
//! or to remove attached childs.
bool CAnimatedMeshSceneNode::removeChild(ISceneNode* child)
{
	if (child && Shadow == child)
	{
		Shadow->drop();
		Shadow = 0;
		return true;
	}

	if (ISceneNode::removeChild(child))
		return true;

	for (s32 i=0; i<(s32)AttachedChilds.size(); ++i)
		if (AttachedChilds[i].node == child)
		{
			AttachedChilds[i].node->drop();
			AttachedChilds.erase(i);
			return true;
		}

	return false;
}


} // end namespace scene
} // end namespace irr

