// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CIrrDeviceStub.h"
#include "IEventReceiver.h"
#include "irrList.h"
#include "os.h"
#include "IrrCompileConfig.h"
#include "CTimer.h"
#include "irrlicht.h"
#include <wchar.h>

namespace irr
{

//! constructor
CIrrDeviceStub::CIrrDeviceStub()
{
	wchar_t tmp[255];
	swprintf(tmp, 255, L"Irrlicht Engine version %s", getVersion());
	os::Debuginfo::print(tmp);

	// create timer
	Timer = new irr::CTimer();

	// create filesystem
	FileSystem = io::createFileSystem();
}


CIrrDeviceStub::~CIrrDeviceStub()
{
	FileSystem->drop();

	if (GUIEnvironment)
		GUIEnvironment->drop();

	if (VideoDriver)
		VideoDriver->drop();

	if (SceneManager)
		SceneManager->drop();

	if (CursorControl)
		CursorControl->drop();

	CursorControl = 0;

	Timer->drop();
}


void CIrrDeviceStub::createGUIAndScene(IEventReceiver* receiver)
{
	// create gui environment
	GUIEnvironment = gui::createGUIEnvironment(FileSystem, VideoDriver, receiver);

	// create Scene manager
	SceneManager = scene::createSceneManager(VideoDriver, FileSystem, CursorControl);
}


//! returns the video driver
video::IVideoDriver* CIrrDeviceStub::getVideoDriver()
{
	return VideoDriver;
}



//! return file system
io::IFileSystem* CIrrDeviceStub::getFileSystem()
{
	return FileSystem;
}



//! returns the gui environment
gui::IGUIEnvironment* CIrrDeviceStub::getGUIEnvironment()
{
	return GUIEnvironment;
}



//! returns the scene manager
scene::ISceneManager* CIrrDeviceStub::getSceneManager()
{
	return SceneManager;
}


//! \return Returns a pointer to the ITimer object. With it the
//! current Time can be received.
ITimer* CIrrDeviceStub::getTimer()
{
	return Timer;
}


//! Returns the version of the engine. 
const wchar_t* CIrrDeviceStub::getVersion()
{
	return L"0.4";
}

//! \return Returns a pointer to the mouse cursor control interface.
gui::ICursorControl* CIrrDeviceStub::getCursorControl()
{
	return CursorControl;
}


//! \return Returns a pointer to a list with all video modes supported
//! by the gfx adapter.
video::IVideoModeList* CIrrDeviceStub::getVideoModeList()
{
	return &VideoModeList;
}


} // end namespace irr
