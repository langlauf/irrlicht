// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CGUIStaticText.h"
#include "IGUISkin.h"
#include "IGUIEnvironment.h"
#include "IGUIFont.h"
#include "IVideoDriver.h"

namespace irr
{
namespace gui
{



//! constructor
CGUIStaticText::CGUIStaticText(const wchar_t* text, bool border, IGUIEnvironment* environment, IGUIElement* parent, s32 id, const core::rect<s32>& rectangle)
: IGUIStaticText(environment, parent, id, rectangle), Border(border),
	OverrideFont(0), OverrideColorEnabled(false)
{
	#ifdef _DEBUG
	setDebugName("CGUIStaticText");
	#endif

	OverrideColor = video::SColor(101,255,255,255);
	Text = text;
}


//! destructor
CGUIStaticText::~CGUIStaticText()
{
	if (OverrideFont)
		OverrideFont->drop();
}


//! draws the element and its children
void CGUIStaticText::draw()
{
	if (!IsVisible)
		return;

	IGUISkin* skin = Environment->getSkin();
	irr::video::IVideoDriver* driver = Environment->getVideoDriver();

	core::rect<s32> frameRect(AbsoluteRect);

	// draw the border

	if (Border)
	{
		frameRect.LowerRightCorner.Y = frameRect.UpperLeftCorner.Y + 1;
		driver->draw2DRectangle(skin->getColor(EGDC_3D_SHADOW), frameRect, &AbsoluteClippingRect);

		frameRect.LowerRightCorner.Y = AbsoluteRect.LowerRightCorner.Y;
		frameRect.LowerRightCorner.X = frameRect.UpperLeftCorner.X + 1;
		driver->draw2DRectangle(skin->getColor(EGDC_3D_SHADOW), frameRect, &AbsoluteClippingRect);

		frameRect = AbsoluteRect;
		frameRect.UpperLeftCorner.X = frameRect.LowerRightCorner.X - 1;
		driver->draw2DRectangle(skin->getColor(EGDC_3D_HIGH_LIGHT), frameRect, &AbsoluteClippingRect);

		frameRect = AbsoluteRect;
		frameRect.UpperLeftCorner.Y = AbsoluteRect.LowerRightCorner.Y - 1;
		frameRect.LowerRightCorner.Y = AbsoluteRect.LowerRightCorner.Y;
		driver->draw2DRectangle(skin->getColor(EGDC_3D_HIGH_LIGHT), frameRect, &AbsoluteClippingRect);

		frameRect = AbsoluteRect;
		frameRect.UpperLeftCorner.X += 3;
	}


	// draw the text
	if (Text.size())
	{
		IGUIFont* font = OverrideFont;
		if (!OverrideFont)
			font = skin->getFont();

		if (font)
			font->draw(Text.c_str(), frameRect, 
			OverrideColorEnabled ? OverrideColor : skin->getColor(EGDC_BUTTON_TEXT),
			false, true, &AbsoluteRect);
	}

	IGUIElement::draw();
}



//! Sets another skin independent font.
void CGUIStaticText::setOverrideFont(IGUIFont* font)
{
	if (OverrideFont)
		OverrideFont->drop();

	OverrideFont = font;

	if (OverrideFont)
		OverrideFont->grab();
}


//! Sets another color for the text.
void CGUIStaticText::setOverrideColor(video::SColor color)
{
	OverrideColor = color;
	OverrideColorEnabled = true;
}



//! Sets if the static text should use the overide color or the
//! color in the gui skin.
void CGUIStaticText::enableOverrrideColor(bool enable)
{
	OverrideColorEnabled = enable;
}



} // end namespace gui
} // end namespace irr

