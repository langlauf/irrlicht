// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CShadowVolumeSceneNode.h"
#include "ISceneManager.h"
#include "IVideoDriver.h"

namespace irr
{
namespace scene
{


//! constructor
CShadowVolumeSceneNode::CShadowVolumeSceneNode(ISceneNode* parent, ISceneManager* mgr, s32 id)
: IShadowVolumeSceneNode(parent, mgr, id), Edges(0), EdgeCount(0), 
	ShadowVolumesUsed(0), Indices(0), Vertices(0), IndexCount(0), VertexCount(0),
	IndexCountAllocated(0), VertexCountAllocated(0)
{
}



//! destructor
CShadowVolumeSceneNode::~CShadowVolumeSceneNode()
{
	if (Edges)
		delete [] Edges;

	for (u32 i=0; i<ShadowVolumes.size(); ++i)
		delete [] ShadowVolumes[i].vertices;

	delete [] Vertices;
	delete [] Indices;
}



void CShadowVolumeSceneNode::addEdge(s32& numEdges, u16 v0, u16 v1)
{
	/*for(s32 i=0; i<numEdges; ++i)
	{
		if ((Edges[2*i+0] == v0 && Edges[2*i+1] == v1) ||
		    (Edges[2*i+0] == v1 && Edges[2*i+1] == v0))
		{
			if (numEdges > 1)
			{
				Edges[2*i+0] = Edges[2*(numEdges-1)+0];
				Edges[2*i+1] = Edges[2*(numEdges-1)+1];
			}

			--numEdges;
			return;
		}
	}*/

	Edges[2*numEdges+0] = v0;
	Edges[2*numEdges+1] = v1;
	++numEdges;
}


void CShadowVolumeSceneNode::createShadowVolume(const core::vector3df& light)
{
	SShadowVolume* svp = 0;

	// builds the shadow volume and adds it to the shadow volume list.

	if (ShadowVolumes.size() > (u32)ShadowVolumesUsed)
	{
		// get the next unused buffer
		svp = &ShadowVolumes[ShadowVolumesUsed];
		if (svp->size >= IndexCount*5)
			svp->count = 0;
		else
		{
			svp->size = IndexCount*5;
			svp->count = 0;
			delete [] svp->vertices;
			svp->vertices = new core::vector3df[svp->size];
		}

		++ShadowVolumesUsed;
	}
	else
	{
		// add a buffer
		SShadowVolume tmp;
		ShadowVolumes.push_back(tmp);	
		svp = &ShadowVolumes[ShadowVolumes.size()-1];
		++ShadowVolumesUsed;

		// wir machen mal einen ziemlich gro�en shadowbuffer
		svp->size = IndexCount*5;
		svp->count = 0;
		svp->vertices = new core::vector3df[svp->size];
	}

	s32 faceCount = (int)(IndexCount / 3);

	if (faceCount * 6 > EdgeCount || !Edges)
	{
		delete [] Edges;
		EdgeCount = faceCount * 6;
		Edges = new u16[EdgeCount];
	}

	

	s32 numEdges = 0;
	core::vector3df normal;
	unsigned short wFace0, wFace1, wFace2;

	core::vector3df ls = light * 200.0f; // light scaled

	s32 i;

	for (i=0; i<faceCount; ++i)
	{
		wFace0 = Indices[3*i+0];
        wFace1 = Indices[3*i+1];
		wFace2 = Indices[3*i+2];

		core::vector3df v0(Vertices[wFace2] - Vertices[wFace1]);
		core::vector3df v1(Vertices[wFace1] - Vertices[wFace0]);

		normal = v0.crossProduct(v1);

		if (normal.dotProduct(light) >= 0.0f)
		{
			addEdge(numEdges, wFace0, wFace1);
            addEdge(numEdges, wFace1, wFace2);
            addEdge(numEdges, wFace2, wFace0);
		}
	}

	for (i=0; i<numEdges; ++i)
    {
		core::vector3df &v1 = Vertices[Edges[2*i+0]];
		core::vector3df &v2 = Vertices[Edges[2*i+1]];
		core::vector3df v3(v1 - ls);
		core::vector3df v4(v2 - ls);

		// Add a quad (two triangles) to the vertex list
		svp->vertices[svp->count++] = v1;
		svp->vertices[svp->count++] = v2;
		svp->vertices[svp->count++] = v3;

		svp->vertices[svp->count++] = v2;
		svp->vertices[svp->count++] = v4;
		svp->vertices[svp->count++] = v3;
	}
}

//! sets the mesh from which the shadow volume should be generated.
void CShadowVolumeSceneNode::setMeshToRenderFrom(IMesh* mesh)
{
	ShadowVolumesUsed = 0;
	VertexCount = 0;
	IndexCount = 0;

	if (!mesh)
		return;

	// calculate total amount of vertices and indices

	s32 i;
	s32 totalVertices = 0;
	s32 totalIndices = 0;
	s32 bufcnt = mesh->getMeshBufferCount();
	IMeshBuffer* b;

	for (i=0; i<bufcnt; ++i)
	{
		b = mesh->getMeshBuffer(i);
		totalIndices += b->getIndexCount();
		totalVertices += b->getVertexCount();
	}

	// allocate memory if nececcary

	if (totalVertices > VertexCountAllocated)
	{
		delete [] Vertices;
		Vertices = new core::vector3df[totalVertices];
		VertexCountAllocated = totalVertices;
	}

	if (totalIndices > IndexCountAllocated)
	{
		delete [] Indices;
		Indices = new u16[totalIndices];
		IndexCountAllocated = totalIndices;
	}

	// copy mesh
	
	for (i=0; i<bufcnt; ++i)
	{
		b = mesh->getMeshBuffer(i);
		
		s32 idxcnt = b->getIndexCount();
		s32 vtxnow = VertexCount;

		const u16* idxp = b->getIndices();
		const u16* idxpend = idxp + idxcnt;

		for (; idxp!=idxpend; ++idxp)
			Indices[IndexCount++] = *idxp + vtxnow;

		s32 vtxcnt = b->getVertexCount();

		switch(b->getVertexType())
		{
		case video::EVT_STANDARD:
			{
				const video::S3DVertex* vp = (video::S3DVertex*)b->getVertices();
				const video::S3DVertex* vpend = vp + vtxcnt;

				for (; vp!=vpend; ++vp)
					Vertices[VertexCount++] = (*vp).Pos;
			}
			break;
		case video::EVT_2TCOORDS:
			{
				const video::S3DVertex2TCoords* vp = (video::S3DVertex2TCoords*)b->getVertices();
				const video::S3DVertex2TCoords* vpend = vp + vtxcnt;

				for (; vp!=vpend; ++vp)
					Vertices[VertexCount++] = (*vp).Pos;
			}
			break;
		}
	}

	// create as much shadow volumes as there are lights but 
	// do not ignore the max light settings.

	s32 lights = SceneManager->getVideoDriver()->getDynamicLightCount();
	core::matrix4 mat = Parent->getAbsoluteTransformation();
	core::vector3df parentpos = Parent->getAbsolutePosition();
	core::vector3df lpos;
	mat.makeInverse();

	for (i=0; i<lights; ++i)
	{
		const video::SLight& dl = SceneManager->getVideoDriver()->getDynamicLight(i);
		lpos = dl.Position;
		if (dl.CastShadows && (lpos - parentpos).getLength() <= dl.Radius)
		{
			mat.transformVect(lpos);
			createShadowVolume(lpos);
		}
	}
}



//! pre render method
void CShadowVolumeSceneNode::OnPreRender()
{
	if (IsVisible)
		SceneManager->registerNodeForRendering(this, scene::SNRT_SHADOW);
}



//! renders the node.
void CShadowVolumeSceneNode::render()
{
	video::IVideoDriver* driver = SceneManager->getVideoDriver();

	if (!ShadowVolumesUsed || !driver)
		return;

	driver->setTransform(video::TS_WORLD, Parent->getAbsoluteTransformation());

	for (s32 i=0; i<ShadowVolumesUsed; ++i)
		driver->drawStencilShadowVolume(ShadowVolumes[i].vertices, ShadowVolumes[i].count);
}



//! returns the axis aligned bounding box of this node
const core::aabbox3d<f32>& CShadowVolumeSceneNode::getBoundingBox() const
{
	return Box;
}



//! returns the material based on the zero based index i.
video::SMaterial& CShadowVolumeSceneNode::getMaterial(s32 i)
{
	// this should never be called, because a shadow volume has got no
	// material
	return *((video::SMaterial*)(0));

}



//! returns amount of materials used by this scene node.
s32 CShadowVolumeSceneNode::getMaterialCount()
{
	return 0;
}


} // end namespace scene
} // end namespace irr
