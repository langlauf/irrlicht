#ifndef __C_SCENE_COLLISION_MANAGER_H_INCLUDED__
#define __C_SCENE_COLLISION_MANAGER_H_INCLUDED__

// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "ISceneCollisionManager.h"
#include "ISceneManager.h"
#include "IVideoDriver.h"

namespace irr
{
namespace scene
{

	//!	The Scene Collision Manager provides methods for performing collision tests and picking on scene nodes.
	class CSceneCollisionManager : public ISceneCollisionManager
	{
	public:

		//! constructor
		CSceneCollisionManager(ISceneManager* smanager, video::IVideoDriver* driver);

		//! destructor
		virtual ~CSceneCollisionManager();

		//! Returns the scene node, which is currently visible under the overgiven 
		//! screencoordinates, viewed from the currently active camera. 
		virtual ISceneNode* getSceneNodeFromSceenCoordinates(core::position2d<s32> pos,
			s32 idBitMask=0);

		//! Returns the nearest scene node which collides with a 3d ray and 
		//! which id matches a bitmask. 
		virtual ISceneNode* getSceneNodeFromRay(core::line3d<f32> ray, s32 idBitMask=0);

		//! Returns the scene node, at which the overgiven camera is looking at and
		//! which id matches the bitmask.
		virtual ISceneNode* getSceneNodeFromCamera(ICameraSceneNode* camera, s32 idBitMask=0);

	private:

		void getPicked(ISceneNode* root, const core::vector3df& linemiddle, 
				const core::vector3df& linevect,
				const core::vector3df& pos, 
				f32 halflenght, s32 bits, f32& outdist,
				ISceneNode*& outbest);

		ISceneManager* SceneManager;
		video::IVideoDriver* Driver;
	};


} // end namespace scene
} // end namespace irr

#endif

