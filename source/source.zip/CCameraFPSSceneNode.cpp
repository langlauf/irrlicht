// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CCameraFPSSceneNode.h"
#include "IVideoDriver.h"
#include "ISceneManager.h"
#include "os.h"
#include "Keycodes.h"

namespace irr
{
namespace scene
{

//! constructor
CCameraFPSSceneNode::CCameraFPSSceneNode(ISceneNode* parent, ISceneManager* mgr,
		gui::ICursorControl* cursorControl, s32 id, f32 rotateSpeed , f32 moveSpeed )
: CCameraSceneNode(parent, mgr, id), CursorControl(cursorControl),
	MoveSpeed(moveSpeed), RotateSpeed(rotateSpeed), RotationX(0.0f), 
	RotationY(0.0f), firstUpdate(true)
{
	if (CursorControl)
		CursorControl->grab();

	MoveSpeed /= 1000.0f;

	recalculateViewArea();

	allKeysUp();
}


//! destructor
CCameraFPSSceneNode::~CCameraFPSSceneNode()
{
	if (CursorControl)
		CursorControl->drop();
}


//! It is possible to send mouse and key events to the camera. Most cameras
//! may ignore this input, but camera scene nodes which are created for 
//! example with scene::ISceneManager::addMayaCameraSceneNode or
//! scene::ISceneManager::addMeshViewerCameraSceneNode, may want to get this input
//! for changing their position, look at target or whatever. 
bool CCameraFPSSceneNode::OnEvent(SEvent event)
{
	if (event.EventType == irr::EET_KEY_INPUT_EVENT)
	{
		switch(event.KeyInput.Key)
		{
		case KEY_UP: CursorKeys[0] = event.KeyInput.PressedDown; return true;
		case KEY_DOWN: CursorKeys[1] = event.KeyInput.PressedDown; return true;
		case KEY_LEFT: CursorKeys[2] = event.KeyInput.PressedDown; return true;
		case KEY_RIGHT: CursorKeys[3] = event.KeyInput.PressedDown;	return true;
		}
	}

	return false;
}



//! onPostRender is called just after rendering the whole scene.
//! nodes may calculate or store animations here, and may do other useful things,
//! dependent on what they are.
void CCameraFPSSceneNode::OnPostRender(u32 timeMs)
{
	//updateAbsolutePosition();
	AnimatedRelativeTransformation = RelativeTransformation;
	animate();

	updateAbsolutePosition();

	AnimatedRelativeTransformation = RelativeTransformation;

	core::list<ISceneNodeAnimator*>::Iterator ait = Animators.begin();
				for (; ait != Animators.end(); ++ait)
					(*ait)->animateNode(this, timeMs);

	updateAbsolutePosition();
}



void CCameraFPSSceneNode::animate()
{
	if (SceneManager->getActiveCamera() != this)
		return;

	if (firstUpdate)
	{
		if (CursorControl)
			CursorControl->setPosition(0.5f, 0.5f);

		LastKeyTime = os::Timer::getTime();

		firstUpdate = false;
		return;
	}

	// get time

	s32 now = os::Timer::getTime();
	s32 moved = now - LastKeyTime;
	LastKeyTime = now;

	// Update rotation

	Target.set(0,0,1);

	if (!CursorControl)
		return;

	core::position2d<f32> cursorpos = CursorControl->getRelativePosition();

	if (cursorpos.X < 0.49f || cursorpos.X > 0.51f ||
		cursorpos.Y < 0.49f || cursorpos.Y > 0.51f)
	{
		RotationX += (0.5f - cursorpos.X) * RotateSpeed;
		RotationY += (0.5f - cursorpos.Y) * RotateSpeed;
		CursorControl->setPosition(0.5f, 0.5f);

		if (RotationY > 89.0f)	RotationY = 89.0f;
		if (RotationY < -89.0f)	RotationY = -89.0f;
	}

	// set target

	core::matrix4 mat;
	mat.setRotationDegrees(core::vector3df(-RotationY, -RotationX, 0));
	mat.transformVect(Target);

	// update position

	core::vector3df pos = getRelativePosition();	

	core::vector3df movedir = Target;
	movedir.normalize();

	if (CursorKeys[0])
		pos += movedir * (f32)moved * MoveSpeed;

	if (CursorKeys[1])
		pos -= movedir * (f32)moved * MoveSpeed;

	// strafing

	core::vector3df strafevect = Target;
	strafevect = strafevect.crossProduct(UpVector);
	strafevect.normalize();

	if (CursorKeys[2])
		pos += strafevect * (f32)moved * MoveSpeed;

	if (CursorKeys[3])
		pos -= strafevect * (f32)moved * MoveSpeed;

	// write translation

	AnimatedRelativeTransformation = RelativeTransformation;
	AnimatedRelativeTransformation.setTranslation(pos);
	RelativeTransformation = AnimatedRelativeTransformation;

	// write right target

	Target += pos;
}


void CCameraFPSSceneNode::allKeysUp()
{
	for (s32 i=0; i<4; ++i)
		CursorKeys[i] = false;
}


} // end namespace
} // end namespace

