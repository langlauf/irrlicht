// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "IGUIEnvironment.h"
#include "NativeConverter.h"
#include "IGUIFont.h"

namespace Irrlicht
{
namespace GUI
{

	IGUIEnvironment::IGUIEnvironment(irr::gui::IGUIEnvironment* env)
		: Environment(env), BuildInFont(0)
	{
		Environment->grab();

		irr::gui::IGUIFont* font = Environment->getBuiltInFont();
		if (font)
			BuildInFont = new IGUIFont(font); 
	}


	IGUIEnvironment::~IGUIEnvironment()
	{
		Environment->drop();
	}

	IGUIFont* IGUIEnvironment::GetFont(System::String* filename)
	{
		char* str = (char*)(void*)
			System::Runtime::InteropServices::Marshal::StringToHGlobalAnsi(filename);

		irr::gui::IGUIFont* font = Environment->getFont(str);
		if (!font)
			return 0;

		return new IGUIFont(font);
	}

	IGUIFont* IGUIEnvironment::get_BuiltInFont()
	{
		return BuildInFont;
	}
}
}