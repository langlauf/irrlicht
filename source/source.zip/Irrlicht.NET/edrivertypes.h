// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

#ifndef __E_DRIVER_TYPES_NET_H_INCLUDED__
#define __E_DRIVER_TYPES_NET_H_INCLUDED__

namespace Irrlicht
{
namespace Video
{
	/// <summary>
	/// An enum for all types of drivers the Irrlicht Engine supports.
	/// </summary>
	__value public enum DriverType
	{
		/// <summary> Null device, useful for applications to run the engine without visualisation. 
		/// The null device is able to load textures, but does not render and display
		/// any graphics.
        /// </summary>
		NULL_DRIVER,     

		/// <summary>
		/// The Irrlicht Engine Software renderer, runs on all platforms,
		/// with every hardware. Is slow and does not support every renderstate correctly.
		/// It should only be used for 2d graphics, but it can also perform some
		/// primitive 3d functions.
		/// </summary>
		SOFTWARE, 

		/// <summary>
		/// DirectX 8 device, only available on Win32 platforms including Win95, Win98, WinNT,
		/// Win2K, WinXP.
		/// </summary>
		DIRECTX8, 

		/// <summary>
		/// DirectX 9 device, only available on Win32 platforms including Win95, Win98, WinNT,
		/// Win2K, WinXP.
		/// </summary>
		DIRECTX9,

		/// <summary> OpenGL device, available on all Win32 platforms and on Linux. </summary>
		OPENGL    
	};

} // end namespace video
} // end namespace irr


#endif

