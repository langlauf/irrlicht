// This is the main DLL file.

#pragma unmanaged
#include "..\\irrlicht\\include\\irrlicht.h"
#pragma comment (lib, "..\\release\\irrlicht.lib")
#pragma managed

#include "Irrlicht.NET.h"
#include "IVideoDriver.h"
#include "ISceneManager.h"
#include "ICursorControl.h"
#include "NativeConverter.h"
#include <vcclr.h> // for PtrToStringChars

namespace Irrlicht
{

IrrlichtDevice::IrrlichtDevice(Video::DriverType driverType, Core::Dimension2D windowSize, 
	int bits, bool fullScreen, bool stencilBuffer, bool vsync)
: Device(0), ManagedVideoDriver(0), ManagedSceneManager(0), ManagedCursorControl(0),
 ManagedEventReceiver(0)
{
	Device = irr::createDevice((irr::video::E_DRIVER_TYPE)driverType,
		irr::NativeConverter::getNativeDim(windowSize), bits, fullScreen, false, vsync);
    
	if (!Device)
		throw new System::Exception(new System::String("Specified device could not be created."));

	ManagedVideoDriver = new Video::IVideoDriver(Device->getVideoDriver());
	ManagedSceneManager = new Scene::ISceneManager(Device->getSceneManager());
	ManagedCursorControl = new GUI::ICursorControl(Device->getCursorControl());
}

IrrlichtDevice::IrrlichtDevice(Video::DriverType driverType)
: Device(0), ManagedVideoDriver(0), ManagedSceneManager(0), ManagedCursorControl(0)
{
	Device = irr::createDevice((irr::video::E_DRIVER_TYPE)driverType);
    
	if (!Device)
		throw new System::Exception(new System::String("Specified device could not be created."));

	ManagedVideoDriver = new Video::IVideoDriver(Device->getVideoDriver());
	ManagedSceneManager = new Scene::ISceneManager(Device->getSceneManager());
	ManagedCursorControl = new GUI::ICursorControl(Device->getCursorControl());
}



//! Destructor
IrrlichtDevice::~IrrlichtDevice()
{
	set_EventReceiver(0);
}


bool IrrlichtDevice::Run()
{
	return Device->run();
}

bool IrrlichtDevice::get_WindowActive()
{
	return Device->isWindowActive();
}

void IrrlichtDevice::CloseDevice()
{
	Device->closeDevice();
}

System::String* IrrlichtDevice::get_Version()
{
	return new System::String(Device->getVersion());
}

void IrrlichtDevice::set_ResizeAble(bool resize)
{
	return Device->setResizeAble(resize);
}

void IrrlichtDevice::set_WindowCaption(System::String* text)
{
	const wchar_t __pin* pinchars = PtrToStringChars(text); 
	Device->setWindowCaption(pinchars);
}

Video::IVideoDriver* IrrlichtDevice::get_VideoDriver()
{
	return ManagedVideoDriver;
}

Scene::ISceneManager* IrrlichtDevice::get_SceneManager()
{
	return ManagedSceneManager;
}

GUI::ICursorControl* IrrlichtDevice::get_CursorControl()
{
	return ManagedCursorControl;
}

void IrrlichtDevice::set_EventReceiver(IEventReceiver* receiver)
{
	if (EventMapList == 0)
		EventMapList = new System::Collections::ArrayList();
	else
	if (ManagedEventReceiver != 0)
	{
		// search and delete current EventReceiver from list

		for (int i=0; i<EventMapList->get_Count(); ++i)
		{
			SEventMapping* mapping = __try_cast<SEventMapping*>(EventMapList->get_Item(i));
			if (mapping->ManagedEventReceiver == ManagedEventReceiver)
			{
				delete mapping->NativeEventReceiver;
				EventMapList->RemoveAt(i);
				break;
			}
		}
		
	}

	if (receiver != 0)
	{
		SEventMapping* map = new SEventMapping();
		map->ManagedEventReceiver = receiver;
		map->NativeEventReceiver = new NativeEventReceiver();
		ManagedEventReceiver = receiver;

		EventMapList->Add(map);
		Device->setEventReceiver(map->NativeEventReceiver);
	}
	else
	{
		Device->setEventReceiver(0);
		ManagedEventReceiver = 0;
	}
}

bool IrrlichtDevice::NativeEventReceiver::OnEvent(irr::SEvent e)
{
	// find .NET receiver
	System::Collections::ArrayList* l = IrrlichtDevice::get_EventMap();
	if (!l)
		return false;

	// this is not as slow as it looks, because the list usually has
	// only one single entry.
	for (int i=0; i<l->get_Count(); ++i)
	{
		SEventMapping* mapping = __try_cast<SEventMapping*>(l->get_Item(i));
		if (mapping->NativeEventReceiver == this)
		{
			// found .NET receiver, now marshal event
			return mapping->ManagedEventReceiver->OnEvent(Irrlicht::Event(e));
		}
	}

	return false;
}

}