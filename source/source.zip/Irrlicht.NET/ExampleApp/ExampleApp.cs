// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

using System;
using Irrlicht;
using Irrlicht.Video;
using Irrlicht.Core;
using Irrlicht.Scene;
using Irrlicht.GUI;

	/// <summary>
	/// Example application using Irrlicht.NET 
	/// </summary>
class ExampleApp : IEventReceiver
{
	/// <summary>
	/// The main entry point for the application.
	/// </summary>
	[STAThread]
	static void Main(string[] args)
	{
		ExampleApp ea = new ExampleApp();

		//ea.testIrrlichtInWindowsForm();

		ea.run();
	}

	/// <summary>
	/// Receives events (like input from mouse and keyboard) from the Irrlicht Engine
	/// </summary>
	public bool OnEvent(Event e)
	{
		if (e.Type == EventType.LogText)
		{
			System.Console.Out.WriteLine(e.LogText);
			return true;
		}
		else
		if (e.Type == EventType.GUIEvent)
		{
			System.Console.Out.WriteLine("GUIEvent:" + e.GUIEventType);
		}

		return false;
	}

	public void run()
	{
		// please note: This program is just a program to test out the features
		// of the irrlicht.net port. If you are looking for examples using Irrlicht.NET
		// please take a look into the examples.net directory.

		IrrlichtDevice device = new IrrlichtDevice(DriverType.DIRECTX8,
			new Dimension2D(800,600), 16, false, false, false);

		device.EventReceiver = this;
		device.ResizeAble = true;
		device.WindowCaption = "Irrlicht.NET test";

		// load some textures and meshes

		ITexture texSydney = device.VideoDriver.GetTexture(@"..\..\media\sydney.bmp");
		ITexture texWall = device.VideoDriver.GetTexture(@"..\..\media\wall.jpg");
		ITexture texLogo = device.VideoDriver.GetTexture(@"..\..\media\irrlichtlogoaligned.jpg");
		Irrlicht.Scene.IAnimatedMesh mesh = 
			device.SceneManager.GetMesh(@"..\..\media\sydney.md2");

		if (mesh == null)
		{
			System.Windows.Forms.MessageBox.Show(
				@"Could not load mesh ..\..\media\sydney.md2, exiting.",
				"Problem starting program");
			return;
		}

		// add a cube to the scene

		ISceneNode node = device.SceneManager.AddTestSceneNode(15,
			null, -1, new Vector3D(30,-15,0));
		node.SetMaterialTexture(0, texWall);

		// add an animator to the cube to make it rotate

		ISceneNodeAnimator anim = device.SceneManager.CreateRotationAnimator(new Vector3D(0.2f, 0.2f, 0));
		node.AddAnimator(anim);

		// add animated mesh 

		node = device.SceneManager.AddAnimatedMeshSceneNode(mesh, null, -1);
		node.SetMaterialTexture(0, texSydney);
		node.SetMaterialFlag(MaterialFlag.LIGHTING, false);

		// add quake 3 level

		device.FileSystem.AddZipFileArchive("../../media/map-20kdm2.pk3");

		IAnimatedMesh q3levelmesh = device.SceneManager.GetMesh("20kdm2.bsp");
		ISceneNode q3node = device.SceneManager.AddOctTreeSceneNode(q3levelmesh, null, -1);
		q3node.Position = new Vector3D(-1370,-130,-1400);

		// create octtree triangle selector for q3 mesh

		ITriangleSelector selector = device.SceneManager.CreateOctTreeTriangleSelector(
			q3levelmesh.GetMesh(0), q3node, 128);

		// create camera

		ICameraSceneNode cam = 
			device.SceneManager.AddCameraSceneNodeFPS(null, 100, 300, -1);
			//device.SceneManager.AddCameraSceneNode(null, new Vector3D(10,10,10), new Vector3D(0,0,0), -1);
		cam.Position = new Vector3D(20,300,-50);

		// make cursor invisible
		device.CursorControl.Visible = false;

		// create collision animator and add it to the camera

		ISceneNodeAnimator collAnim = device.SceneManager.CreateCollisionResponseAnimator(
			selector, cam, 
			new Vector3D(30,50,30),  // size of ellipsoid around camera
			new Vector3D(0, -3, 0),  // gravity
			new Vector3D(0, 50, 0),  // translation
			0.0005f);                // sliding value

		cam.AddAnimator(collAnim);

		// load some font and set it into the skin

		IGUIFont font = device.GUIEnvironment.GetFont("../../media/fonthaettenschweiler.bmp");
		device.GUIEnvironment.Skin.Font = font;

		// add some gui stuff
		
		//device.GUIEnvironment.AddButton(new Rect(50,50,200,100), null, -1, "Hallo!");
		device.GUIEnvironment.AddMessageBox("Hello World", 
			"I'm a Irrlicht.NET MessageBox. Please press SPACE to close me.", true, 
			MessageBoxFlag.OK | MessageBoxFlag.CANCEL, null, -1);
		
		// start drawing loop

		int fps = 0;

		while(device.Run())
			if (device.WindowActive)
			{
				device.VideoDriver.BeginScene(true, true, new Color(255,0,0,50));

				// draw scene

				device.SceneManager.DrawAll();
				device.GUIEnvironment.DrawAll();

				// draw 2d logo
					
				device.VideoDriver.Draw2DImage(
					texLogo, new Position2D(10,10),
					new Rect(0,0,88,31), 
					new Rect(new Position2D(0,0),device.VideoDriver.ScreenSize),
					new Color(0xffffff), false);

				// draw some text 

				device.GUIEnvironment.BuiltInFont.Draw(
					"This is Irrlicht.NET font drawing",
					new Position2D(120,10), new Color(100,255,255,255));

				font.Draw("This is another font",
					new Position2D(120,20), new Color(100,150,200,200));

				device.VideoDriver.EndScene();

				if (fps != device.VideoDriver.FPS)
				{
					fps = device.VideoDriver.FPS;
					device.WindowCaption = "Irrlicht.NET test (primitives:" + 
						device.VideoDriver.PrimitiveCountDrawn + ") fps:" + fps;
				}
			}
	}


	void testIrrlichtInWindowsForm()
	{
		// testing irrlicht running embedded in a windows form
		
		System.Windows.Forms.Form f = new System.Windows.Forms.Form();
		f.Text = "Irrlicht running embedded in Windows.Form";

		IrrlichtDevice device = new IrrlichtDevice(DriverType.DIRECTX8,
			new Dimension2D(800,600), 16, false, false, false, true, f.Handle);

		f.Show();

		device.VideoDriver.BeginScene(true, true, new Color(255,0,0,50));
		device.VideoDriver.EndScene();
	}
}