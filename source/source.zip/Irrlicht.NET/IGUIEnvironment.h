// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#pragma once

#using <mscorlib.dll>
using namespace System;

#pragma unmanaged
#include "..\\irrlicht\\include\\irrlicht.h"
#pragma managed

namespace Irrlicht
{
public __gc class IrrlichtDevice;

namespace GUI
{
	public __gc class IGUIFont;

	public __gc class IGUIEnvironment
	{
	public:

		/// <summary>
		/// You should access the IGUIEnvironment 
		/// through the Irrlicht::IrrlichtDevice.GUIEnvironment property. Simply don't use
		/// this constructor.
		///</summary>
		///<param name="env">The real, unmanaged C++ GUI Environment</param>
		IGUIEnvironment(irr::gui::IGUIEnvironment* env);

		~IGUIEnvironment();

		/// <summary>
		/// Returns pointer to the font with the specified file name. 
		/// Loads the font if it was not loaded before. Returns 0 if the font could not be loaded.
		/// </summary>
		/// <returns> returns a pointer to the font. </returns>
		IGUIFont* GetFont(System::String* filename);

		/// <summary>
		/// Returns the default built-in font.
		/// </summary>
		__property IGUIFont* get_BuiltInFont();

	private:

		irr::gui::IGUIEnvironment* Environment;
		IGUIFont* BuildInFont;
	};

}
}
