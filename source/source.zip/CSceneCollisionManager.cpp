#include "CSceneCollisionManager.h"
#include "ISceneNode.h"
#include "ICameraSceneNode.h"

namespace irr
{
namespace scene
{

//! constructor
CSceneCollisionManager::CSceneCollisionManager(ISceneManager* smanager, video::IVideoDriver* driver)
: Driver(driver), SceneManager(smanager)
{
	#ifdef _DEBUG
	setDebugName("CSceneCollisionManager");
	#endif

	if (Driver)
		Driver->grab();
}



//! destructor
CSceneCollisionManager::~CSceneCollisionManager() 
{
	if (Driver)
		Driver->drop();
}



//! Returns the scene node, which is currently visible under the overgiven 
//! screencoordinates, viewed from the currently active camera. 
ISceneNode* CSceneCollisionManager::getSceneNodeFromSceenCoordinates(core::position2d<s32> pos, s32 idBitMask)
{
	if (!SceneManager || !Driver)
		return 0; 

	const scene::SViewFrustrum* f = 
		SceneManager->getActiveCamera()->getViewFrustrum();

	core::vector3df farLeftUp = f->getFarLeftUp();
	core::vector3df lefttoright = f->getFarRightUp() - farLeftUp;
	core::vector3df uptodown = f->getFarLeftDown() - farLeftUp;

	core::dimension2d<s32> screenSize = Driver->getScreenSize();

	f32 dx = pos.X / (f32)screenSize.Width;
	f32 dy = pos.Y / (f32)screenSize.Height;

	core::vector3df end = farLeftUp + (lefttoright * dx) + (uptodown * dy);
 
	return getSceneNodeFromRay(core::line3d<f32>(f->cameraPosition, end), idBitMask);
}



//! Returns the nearest scene node which collides with a 3d ray and 
//! which id matches a bitmask. 
ISceneNode* CSceneCollisionManager::getSceneNodeFromRay(core::line3d<f32> ray, s32 idBitMask)
{
	ISceneNode* best = 0;
	f32 dist = 9999999999.0f;

	getPicked(SceneManager->getRootSceneNode(), ray.getMiddle(),
		ray.getVector().normalize(), ray.start, (f32)(ray.getLenght() * 0.5),
		idBitMask, dist, best);

	return best;
}


void CSceneCollisionManager::getPicked(ISceneNode* root,
									   const core::vector3df& linemiddle, 
									   const core::vector3df& linevect,
									   const core::vector3df& pos, 
									   f32 halflenght, s32 bits,
									   f32& outbestdistance,
									   ISceneNode*& outbestnode)
{
	const core::list<ISceneNode*>& children = root->getChildren();

	core::list<ISceneNode*>::Iterator it = children.begin();

	for (; it != children.end(); ++it)
	{
		ISceneNode* current = *it;

		if (current->isVisible() && 
			(bits==0 || (bits != 0 && (current->getID() & bits))))
		{
			if (current->getTransformedBoundingBox().intersectsWithLine(
				linemiddle, linevect, halflenght))
			{
				f32 dist = 	(f32)current->getAbsolutePosition().getDistanceFrom(pos);
				if (dist < outbestdistance)
				{
					outbestnode = current;
					outbestdistance = dist;
				}
			}
		}

		getPicked(current, linemiddle, linevect, pos, 
			halflenght, bits, outbestdistance, outbestnode);
	}
}



//! Returns the scene node, at which the overgiven camera is looking at and
//! which id matches the bitmask.
ISceneNode* CSceneCollisionManager::getSceneNodeFromCamera(ICameraSceneNode* camera, s32 idBitMask)
{
	if (!camera)
		return 0;

	core::vector3df start = camera->getAbsolutePosition();
	core::vector3df end = camera->getTarget();

	end = start + ((end - start).normalize() * camera->getFarValue());
	core::line3d<f32> line(start, end);

	return getSceneNodeFromRay(line, idBitMask);
}


} // end namespace scene
} // end namespace irr

