// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CGeometryCreator.h"
#include "SAnimatedMesh.h"
#include "SMeshBuffer.h"
#include "SMesh.h"

namespace irr
{
namespace scene
{

// creates a hill plane
IAnimatedMesh* CGeometryCreator::createHillPlaneMesh(const core::dimension2d<f32>& tileSize, const core::dimension2d<s32>& tc,
	video::SMaterial* material,	f32 hillHeight, const core::dimension2d<f32>& ch,
	const core::dimension2d<f32>& textureRepeatCount)
{
	core::dimension2d<s32> tileCount = tc;
	tileCount.Height += 1;
	tileCount.Width += 1;

    core::dimension2d<f32> countHills = ch;
    
	SMeshBuffer* buffer = new SMeshBuffer();
	SMesh* mesh = new SMesh();
	video::S3DVertex vtx;
	vtx.Color.set(255,255,255,255);
	vtx.Normal.set(0,1,0);

	if (countHills.Width < 0.01f) countHills.Width = 1;
	if (countHills.Height < 0.01f) countHills.Height = 1;

	float halfX = (tileSize.Width * tileCount.Width) / 2;
	float halfY = (tileSize.Height * tileCount.Height) / 2;

	// create vertices

	s32 x = 0;
	s32 y = 0;

	core::dimension2d<f32> tx;
	tx.Width = 1.0f / (tileCount.Width / textureRepeatCount.Width);
	tx.Height = 1.0f / (tileCount.Height / textureRepeatCount.Height);
	

	for (x=0; x<tileCount.Width; ++x)
		for (y=0; y<tileCount.Height; ++y)
		{
			vtx.Pos.set(tileSize.Width * x - halfX, 0, tileSize.Height * y - halfY);
			vtx.TCoords.set(-(f32)x * tx.Width, (f32)y * tx.Height);
			
			if (hillHeight)
				vtx.Pos.Y = (f32)(sin(vtx.Pos.X * countHills.Width * irr::core::PI / halfX) *
					cos(vtx.Pos.Z * countHills.Height * irr::core::PI / halfY))
					*hillHeight;

			buffer->Vertices.push_back(vtx);
		}

	// create indices

	for (x=0; x<tileCount.Width-1; ++x)
		for (y=0; y<tileCount.Height-1; ++y)
		{
			s32 current = y*tileCount.Width + x;

			buffer->Indices.push_back(current);
			buffer->Indices.push_back(current + 1);
			buffer->Indices.push_back(current + tileCount.Width);

			buffer->Indices.push_back(current + 1);
			buffer->Indices.push_back(current + 1 + tileCount.Width);
			buffer->Indices.push_back(current + tileCount.Width);
		}

	// recalculate normals
	for (s32 i=0; i<(s32)buffer->Indices.size(); i+=3)
	{
		core::plane3d<f32> p(
			buffer->Vertices[buffer->Indices[i+0]].Pos,
			buffer->Vertices[buffer->Indices[i+1]].Pos,
			buffer->Vertices[buffer->Indices[i+2]].Pos);
		p.Normal.normalize();

		buffer->Vertices[buffer->Indices[i+0]].Normal = p.Normal;
		buffer->Vertices[buffer->Indices[i+1]].Normal = p.Normal;
		buffer->Vertices[buffer->Indices[i+2]].Normal = p.Normal;
	}

	if (material)
		buffer->Material = *material;

	buffer->recalculateBoundingBox();

	SAnimatedMesh* animatedMesh = new SAnimatedMesh();
	mesh->addMeshBuffer(buffer);
	mesh->recalculateBoundingBox();
	animatedMesh->addMesh(mesh);
	animatedMesh->recalculateBoundingBox();

	mesh->drop();
	buffer->drop();

	return animatedMesh;
}


} // end namespace scene
} // end namespace irr
