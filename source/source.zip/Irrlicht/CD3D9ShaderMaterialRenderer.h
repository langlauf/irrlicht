// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#ifndef __C_D3D9_SHADER_MATERIAL_RENDERER_H_INCLUDED__
#define __C_D3D9_SHADER_MATERIAL_RENDERER_H_INCLUDED__

#ifdef WIN32

#include "IrrCompileConfig.h"
#ifdef _IRR_COMPILE_WITH_DIRECTX_9_
#include <d3d9.h>
#include <d3dx9shader.h>
#pragma comment (lib, "d3dx9.lib")

#include "IMaterialRenderer.h"

namespace irr
{
namespace video  
{

class IVideoDriver;
class IShaderConstantSetCallBack;
class IMaterialRenderer;

//! Class for using vertex and pixel shaders with D3D9
class CD3D9ShaderMaterialRenderer : public IMaterialRenderer
{
public:

	//! Public constructor
	CD3D9ShaderMaterialRenderer(IDirect3DDevice9* d3ddev, video::IVideoDriver* driver, 
		s32& outMaterialTypeNr, const c8* vertexShaderProgram, const c8* pixelShaderProgram,
		IShaderConstantSetCallBack* callback, IMaterialRenderer* baseMaterial);

	//! Destructor
	~CD3D9ShaderMaterialRenderer();

	virtual void OnSetMaterial(video::SMaterial& material, const video::SMaterial& lastMaterial,
		bool resetAllRenderstates, video::IMaterialRendererServices* services);

	virtual void OnUnsetMaterial();

	virtual bool OnRender(IMaterialRendererServices* service, E_VERTEX_TYPE vtxtype);

	//! Returns if the material is transparent.
	virtual bool isTransparent();

protected:

	//! constructor only for use by derived classes who want to
	//! create a fall back material for example.
	CD3D9ShaderMaterialRenderer(IDirect3DDevice9* d3ddev,
								video::IVideoDriver* driver, 
								IShaderConstantSetCallBack* callback,
								IMaterialRenderer* baseMaterial);


	void init(s32& outMaterialTypeNr, const c8* vertexShaderProgram, const c8* pixelShaderProgram);
	bool createPixelShader(const c8* pxsh);
	bool createVertexShader(const char* vtxsh);

	IDirect3DDevice9* pID3DDevice;
	video::IVideoDriver* Driver;
	IShaderConstantSetCallBack* CallBack;
	IMaterialRenderer* BaseMaterial;

	IDirect3DVertexShader9* VertexShader;
	IDirect3DVertexShader9* OldVertexShader;
	IDirect3DPixelShader9* PixelShader;
};


} // end namespace video
} // end namespace irr

#endif
#endif
#endif

