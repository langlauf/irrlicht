// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#if defined(WIN32) || defined(_XBOX)
 
#ifdef WIN32 
	#include <windows.h>
#endif

#ifdef _XBOX
	#include <xtl.h>
#endif

#ifdef _DEBUG
#include <crtdbg.h>
#endif

#endif // defined(WIN32) || defined(_XBOX)


#include "irrlicht.h"

namespace irr
{
	//! stub for calling createDeviceEx
	IRRLICHT_API IrrlichtDevice* IRRCALLCONV createDevice(video::E_DRIVER_TYPE driverType,
											const core::dimension2d<s32>& windowSize,
											u32 bits, bool fullscreen, 
											bool stencilbuffer, bool vsync, IEventReceiver* res,
											const wchar_t* version)
	{
		irr::SIrrlichtCreationParameters p;
		p.DriverType = driverType;
		p.WindowSize = windowSize;
		p.Bits = bits;
		p.Fullscreen = fullscreen;
		p.Stencilbuffer = stencilbuffer;
		p.Vsync = vsync;
		p.EventReceiver = res;	
		p.SDK_version_do_not_use = version;

		return createDeviceEx(p);
	}

} // end namespace irr



#if defined(WIN32) || defined(_XBOX)

#pragma comment(exestr, "Irrlicht Engine (c) 2002-2005 Nikolaus Gebhardt")

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	//_crtBreakAlloc = 1107717;

    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
			#ifdef _DEBUG
				_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CRTDBG_ALLOC_MEM_DF);
			#endif
			break;
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

#endif // defined(WIN32) || defined(_XBOX)
