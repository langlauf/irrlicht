// Copyright (C) 2002-2005 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in irrlicht.h

// This file was originally written by William Finlayson.
// I (Nikolaus Gebhardt) did some minor modifications and changes to it and integrated 
// it into Irrlicht. Thanks a lot to William for his work on this and that he gave me
// his permission to add it into Irrlicht using the zlib license.

#include "IrrCompileConfig.h"
#ifdef _IRR_COMPILE_WITH_OPENGL_

#include "COpenGLSLMaterialRenderer.h"
#include "IGPUProgrammingServices.h"
#include "IShaderConstantSetCallBack.h"
#include "IVideoDriver.h"
#include "os.h"
#include "COpenGLDriver.h"
#include <stdio.h>
#include <string.h>

namespace irr
{
namespace video
{


//! Constructor
COpenGLSLMaterialRenderer::COpenGLSLMaterialRenderer(video::COpenGLDriver* driver, 
		s32& outMaterialTypeNr, const c8* vertexShaderProgram,
		const c8* vertexShaderEntryPointName,
		E_VERTEX_SHADER_TYPE vsCompileTarget,
		const c8* pixelShaderProgram, 
		const c8* pixelShaderEntryPointName,
		E_PIXEL_SHADER_TYPE psCompileTarget,
		IShaderConstantSetCallBack* callback,
		video::IMaterialRenderer* baseMaterial)
	: Driver(driver), BaseMaterial(baseMaterial), CallBack(callback),
		Program(0)
{
	//entry points must always be main, and the compile target isn't selectable
	//it is fine to ignore what has been asked for, as the compiler should spot anything wrong
	//just check that GLSL is available

	if (!(Driver->queryFeature(EVDF_ARB_GLSL_100) |
		  Driver->queryFeature(EVDF_ARB_GLSL_110)))
		  return;
	
	if (BaseMaterial)
		BaseMaterial->grab();

	if (CallBack)
		CallBack->grab();

	init(outMaterialTypeNr, vertexShaderProgram, pixelShaderProgram);
}


//! constructor only for use by derived classes who want to
//! create a fall back material for example.
COpenGLSLMaterialRenderer::COpenGLSLMaterialRenderer(COpenGLDriver* driver,
							IShaderConstantSetCallBack* callback,
							IMaterialRenderer* baseMaterial)
: Driver(driver), BaseMaterial(baseMaterial), CallBack(callback),
		Program(0)
{
	if (BaseMaterial)
		BaseMaterial->grab();

	if (CallBack)
		CallBack->grab();
}


//! Destructor
COpenGLSLMaterialRenderer::~COpenGLSLMaterialRenderer()
{
	if (CallBack)
		CallBack->drop();

	if(Program)
	{
		Driver->extGLDeleteObjectARB(Program);
		Program = 0;
	}

	if (BaseMaterial)
		BaseMaterial->drop ();
}

void COpenGLSLMaterialRenderer::init(s32& outMaterialTypeNr, 
	const c8* vertexShaderProgram, 
	const c8* pixelShaderProgram)
{
	outMaterialTypeNr = -1;

	if (!createProgram()) 
		return;

	if (!createShader(GL_VERTEX_SHADER_ARB, vertexShaderProgram))
		return;

	if (!createShader(GL_FRAGMENT_SHADER_ARB, pixelShaderProgram)) 
		return;

	if (!linkProgram()) 
		return;
	
	// register myself as new material
	outMaterialTypeNr = Driver->addMaterialRenderer(this);
}

bool COpenGLSLMaterialRenderer::OnRender(IMaterialRendererServices* service, 
										 E_VERTEX_TYPE vtxtype)
{
	// call callback to set shader constants
	if (CallBack && (Program))
		CallBack->OnSetConstants(service);

	return true;
}


void COpenGLSLMaterialRenderer::OnSetMaterial(video::SMaterial& material,
											  const video::SMaterial& lastMaterial,
											  bool resetAllRenderstates, 
											  video::IMaterialRendererServices* services)
{
	if (material.MaterialType != lastMaterial.MaterialType || resetAllRenderstates)
	{
		if(Program)
		{
			Driver->extGLUseProgramObjectARB(Program);
			Driver->setCurrentGLSLProgram(Program);
		}

		if (BaseMaterial)
			BaseMaterial->OnSetMaterial(material, material, true, services);
	}

	services->setBasicRenderStates(material, lastMaterial, resetAllRenderstates);
}


void COpenGLSLMaterialRenderer::OnUnsetMaterial()
{
	Driver->extGLUseProgramObjectARB(0);
	Driver->setCurrentGLSLProgram(0);
	if (BaseMaterial)
		BaseMaterial->OnUnsetMaterial();
}

//! Returns if the material is transparent.
bool COpenGLSLMaterialRenderer::isTransparent()
{
	return BaseMaterial ? BaseMaterial->isTransparent() : false; 
}

bool COpenGLSLMaterialRenderer::createProgram()
{
	Program = Driver->extGLCreateProgramObjectARB();
	return true;
}

bool COpenGLSLMaterialRenderer::createShader(GLenum shaderType, const char* shader)
{
	GLhandleARB shaderHandle = Driver->extGLCreateShaderObjectARB(shaderType);

	Driver->extGLShaderSourceARB(shaderHandle, 1, &shader, NULL);
	Driver->extGLCompileShaderARB(shaderHandle);

	int status = 0;

	Driver->extGLGetObjectParameterivARB(shaderHandle, GL_OBJECT_COMPILE_STATUS_ARB, &status);

	if (!status)
	{
		os::Printer::log("GLSL shader failed to compile");
		return false;
	}

	Driver->extGLAttachObjectARB(Program, shaderHandle);

	return true;
}

bool COpenGLSLMaterialRenderer::linkProgram()
{
	Driver->extGLLinkProgramARB(Program);

	int status = 0;

	Driver->extGLGetObjectParameterivARB(Program, GL_OBJECT_LINK_STATUS_ARB, &status);

	if (!status)
	{
		os::Printer::log("GLSL shader program failed to link");
		return false;
	}
	else return true;
}

} // end namespace video
} // end namespace irr


#endif

