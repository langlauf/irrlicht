#include "CVideoNull.h"
#include "CSoftwareTexture.h"
#include "os.h"

namespace irr
{
namespace video
{

//! creates a loader which is able to load windows bitmaps
ISurfaceLoader* createSurfaceLoaderBmp();
//! creates a loader which is able to load jpeg images
ISurfaceLoader* createSurfaceLoaderJPG();
//! creates a loader which is able to load targa images
ISurfaceLoader* createSurfaceLoaderTGA();
//! creates a loader which is able to load psd images
ISurfaceLoader* createSurfaceLoaderPSD();


//! constructor
CVideoNull::CVideoNull(io::IFileSystem* io, const core::dimension2d<s32>& screenSize)
: ScreenSize(screenSize), ViewPort(0,0,0,0), FileSystem(io), PrimitivesDrawn(0)
{
	#ifdef _DEBUG
	setDebugName("CVideoNull");
	#endif

	ViewPort = core::rect<s32>(core::position2d<s32>(0,0), screenSize);

	if (FileSystem)
		FileSystem->grab();

	// create surface loader

	SurfaceLoader.push_back(video::createSurfaceLoaderBmp());
	SurfaceLoader.push_back(video::createSurfaceLoaderJPG());
	SurfaceLoader.push_back(video::createSurfaceLoaderTGA());
	SurfaceLoader.push_back(video::createSurfaceLoaderPSD());
}



//! destructor
CVideoNull::~CVideoNull()
{
	// delete file system 

	if (FileSystem)
		FileSystem->drop();

	// delete textures

	deleteAllTextures();

	// delete surface loader

	for (u32 i=0; i<SurfaceLoader.size(); ++i)
		SurfaceLoader[i]->drop();
}


//! Adds an external surface loader to the engine. 
void CVideoNull::addExternalSurfaceLoader(ISurfaceLoader* loader)
{
	if (!loader)
		return;

	loader->grab();
	SurfaceLoader.push_back(loader);
}


//! deletes all textures
void CVideoNull::deleteAllTextures()
{
	for (u32 i=0; i<Textures.size(); ++i)
		Textures[i].Surface->drop();

	Textures.clear();
}



//! applications must call this method before performing any rendering. returns false if failed.
bool CVideoNull::beginScene(bool backBuffer, bool zBuffer, SColor color)
{
	PrimitivesDrawn = 0;
	return true;
}



//! applications must call this method after performing any rendering. returns false if failed.
bool CVideoNull::endScene()
{
	FPSCounter.registerFrame(os::Timer::getTime());
	return true;
}



//! queries the features of the driver, returns true if feature is available
bool CVideoNull::queryFeature(EK3D_VIDEO_DRIVER_FEATURE feature)
{
	return false;
}



//! sets transformation
void CVideoNull::setTransform(E_TRANSFORMATION_STATE state, const core::matrix4& mat)
{
}



//! sets a material
void CVideoNull::setMaterial(const SMaterial& material)
{
}



//! Removes a texture from the texture cache and deletes it, freeing lot of
//! memory. 
void CVideoNull::removeTexture(ITexture* texture)
{
	for (u32 i=0; i<Textures.size(); ++i)
		if (Textures[i].Surface == texture)
		{
			texture->drop();
			Textures.erase(i);
		}
}


//! Removes all texture from the texture cache and deletes them, freeing lot of
//! memory. 
void CVideoNull::removeAllTextures()
{
	deleteAllTextures();
}



//! loads a Texture
ITexture* CVideoNull::getTexture(const c8* filename, bool generateMipLevels)
{
	ITexture* texture = findTexture(filename);

	if (texture)
		return texture;

	io::IReadFile* file = FileSystem->createAndOpenFile(filename);

	if (file)
	{
		texture = loadTextureFromFile(file, generateMipLevels);
		file->drop();

		if (texture)
		{
			addTexture(texture, filename);
			texture->drop(); // drop it becaus we created it, one grab to much
		}
	}

	if (!texture)
		os::Warning::print("Could not load texture", filename);

	return texture;
}



//! loads a Texture
ITexture* CVideoNull::getTexture(io::IReadFile* file, bool generateMipLevels)
{
	ITexture* texture = 0;

	if (file)
	{
		texture = findTexture(file->getFileName());

		if (texture)
			return texture;

		texture = loadTextureFromFile(file, generateMipLevels);

		if (texture)
		{
			addTexture(texture, file->getFileName());
			texture->drop(); // drop it because we created it, one grab to much
		}
	}

	if (!texture)
		os::Warning::print("Could not load texture", file->getFileName());

	return texture;
}



//! opens the file and loads it into the surface
video::ITexture* CVideoNull::loadTextureFromFile(io::IReadFile* file, bool generateMipLevels)
{
	ITexture* texture = 0;
	ISurface* surface = 0;

	// try to load file based on file extension
	
	u32 i; // new ISO for scoping problem with different compilers

	for (i=0; i<SurfaceLoader.size(); ++i)
		if (SurfaceLoader[i]->isALoadableFileExtension(file->getFileName()))
		{
			surface = SurfaceLoader[i]->loadImage(file);
			if (surface)
				break;
		}

	// try to load file based on what is in it
	if (!surface)
		for (i=0; i<SurfaceLoader.size(); ++i)
		{
			if (i!=0)
				file->seek(0);

			if (SurfaceLoader[i]->isALoadableFileFormat(file))
			{
				file->seek(0);
				surface = SurfaceLoader[i]->loadImage(file);
				if (surface)
					break;
			}
		}


	if (surface)
	{
		// create texture from surface

		#ifdef _DEBUG
		os::Debuginfo::print("Loaded texture", file->getFileName());
		#endif

		texture = createDeviceDependentTexture(surface, generateMipLevels);
		surface->drop();
	}

	return texture;
}



//! adds a surface, not loaded or created by the Irrlicht Engine
void CVideoNull::addTexture(video::ITexture* texture, const c8* filename)
{
	if (texture)
	{
		if (!filename)
			filename = "";

		SSurface s;
		s.Filename = filename;
		s.Filename.make_lower();
		s.Surface = texture;
		texture->grab();

		Textures.push_back(s);
	}
}



//! looks if the image is already loaded
video::ITexture* CVideoNull::findTexture(const c8* filename)
{
	SSurface s;
	if (!filename)
		filename = "";

	s.Filename = filename;
	s.Filename.make_lower();

	s32 index = Textures.binary_search(s);
	if (index != -1)
		return Textures[index].Surface;

	return 0;
}



//! creates a Texture
ITexture* CVideoNull::addTexture(const core::dimension2d<s32>& size, const c8* name)
{
	ISurface* surface = createSurface(size);
	ITexture* t = createDeviceDependentTexture(surface, false);
	surface->drop();
	addTexture(t, name);
	t->drop();
	return t;
}



//! returns a device dependent texture from a software surface (ISurface)
//! THIS METHOD HAS TO BE OVERRIDDEN BY DERIVED DRIVERS WITH OWN TEXTURES
ITexture* CVideoNull::createDeviceDependentTexture(ISurface* surface, bool generateMipLevels)
{
	return new CSoftwareTexture(surface);
}



//! sets a render target
void CVideoNull::setRenderTarget(video::ITexture* texture)
{
}



//! sets a viewport
void CVideoNull::setViewPort(const core::rect<s32>& area)
{
}



//! gets the area of the current viewport
const core::rect<s32>& CVideoNull::getViewPort() const
{
	return ViewPort;
}



//! draws an indexed triangle list
void CVideoNull::drawIndexedTriangleList(const S3DVertex* vertices, s32 vertexCount, const u16* indexList, s32 triangleCount)
{
	PrimitivesDrawn += triangleCount;
}



//! draws an indexed triangle list
void CVideoNull::drawIndexedTriangleList(const S3DVertex2TCoords* vertices, s32 vertexCount, const u16* indexList, s32 triangleCount)
{
	PrimitivesDrawn += triangleCount;
}


//! Draws a 3d line.
void CVideoNull::draw3DLine(const core::vector3df& start, 
							const core::vector3df& end, SColor color,
							f32 thickness)
{
	core::vector3df vect = start.crossProduct(end);
	vect.normalize();
	vect *= thickness;

	S3DVertex vtx[4];

	vtx[0].Color = color;
	vtx[1].Color = color;
	vtx[2].Color = color;
	vtx[3].Color = color;

	vtx[0].Pos = start;
	vtx[1].Pos = end;

	vtx[2].Pos = start + vect;
	vtx[3].Pos = end + vect;
	
	u16 idx[12] = {0,1,2, 0,2,1,   0,1,3, 0,3,1};

	drawIndexedTriangleList(vtx, 4, idx, 4);
}



//! Draws a 3d triangle.
void CVideoNull::draw3DTriangle(const core::triangle3df& triangle, SColor color,
								f32 t)
{
	draw3DLine(triangle.pointA, triangle.pointB, color, t);
	draw3DLine(triangle.pointB, triangle.pointC, color, t);
	draw3DLine(triangle.pointC, triangle.pointA, color, t);
}



//! Draws a 3d axis aligned box.
void CVideoNull::draw3DBox(const core::aabbox3d<f32> box, SColor color, f32 t)
{
	core::vector3df edges[8];
	box.getEdges(edges);
	
	// TODO: optimize into one big drawIndexePrimitive call.

	draw3DLine(edges[5], edges[1], color, t);
	draw3DLine(edges[1], edges[3], color, t);
	draw3DLine(edges[3], edges[7], color, t);
	draw3DLine(edges[7], edges[5], color, t);
	draw3DLine(edges[0], edges[2], color, t);
	draw3DLine(edges[2], edges[6], color, t);
	draw3DLine(edges[6], edges[4], color, t);
	draw3DLine(edges[4], edges[0], color, t);
	draw3DLine(edges[1], edges[0], color, t);
	draw3DLine(edges[3], edges[2], color, t);
	draw3DLine(edges[7], edges[6], color, t);
	draw3DLine(edges[5], edges[4], color, t);
}



//! draws an 2d image
void CVideoNull::draw2DImage(video::ITexture* texture, const core::position2d<s32>& destPos)
{
}



//! draws an 2d image, using a color (if color is other then Color(255,255,255,255)) and the alpha channel of the texture if wanted.
void CVideoNull::draw2DImage(video::ITexture* texture, const core::position2d<s32>& destPos,
							 const core::rect<s32>& sourceRect,
							 const core::rect<s32>* clipRect, SColor color,
							 bool useAlphaChannelOfTexture)
{
}



//! draw an 2d rectangle
void CVideoNull::draw2DRectangle(SColor color, const core::rect<s32>& pos, const core::rect<s32>* clip)
{
}


//! Draws a 2d line. 
void CVideoNull::draw2DLine(const core::position2d<s32>& start,
								const core::position2d<s32>& end, 
								SColor color)
{
}




//! returns screen size
core::dimension2d<s32> CVideoNull::getScreenSize()
{
	return ScreenSize;
}



// returns current frames per second value
s32 CVideoNull::getFPS()
{
	return FPSCounter.getFPS();
}



//! returns amount of primitives (mostly triangles) were drawn in the last frame.
//! very useful method for statistics.
u32 CVideoNull::getPrimitiveCountDrawn()
{
	return PrimitivesDrawn;
}



//! Sets the dynamic ambient light color. The default color is
//! (0,0,0,0) which means it is dark.
//! \param color: New color of the ambient light.
void CVideoNull::setAmbientLight(const SColorf& color)
{
}



//! \return Returns the name of the video driver. Example: In case of the DirectX8
//! driver, it would return "Direct3D8".
const wchar_t* CVideoNull::getName()
{
	return L"NullDevice";
}



//! Draws a shadow volume into the stencil buffer. To draw a stencil shadow, do
//! this: Frist, draw all geometry. Then use this method, to draw the shadow
//! volume. Then, use IVideoDriver::drawStencilShadow() to visualize the shadow.
void CVideoNull::drawStencilShadowVolume(const core::vector3df* triangles, s32 count, bool zfail)
{
}


//! Fills the stencil shadow with color. After the shadow volume has been drawn
//! into the stencil buffer using IVideoDriver::drawStencilShadowVolume(), use this
//! to draw the color of the shadow. 
void CVideoNull::drawStencilShadow(bool clearStencilBuffer, video::SColor leftUpEdge, 
	video::SColor rightUpEdge,	video::SColor leftDownEdge,	video::SColor rightDownEdge)
{
}


//! deletes all dynamic lights there are
void CVideoNull::deleteAllDynamicLights()
{
	Lights.set_used(0);
}



//! adds a dynamic light
void CVideoNull::addDynamicLight(const SLight& light)
{
	Lights.push_back(light);
}



//! returns the maximal amount of dynamic lights the device can handle
s32 CVideoNull::getMaximalDynamicLightAmount()
{
	return 0;
}

//! Returns current amount of dynamic lights set
//! \return Current amount of dynamic lights set
s32 CVideoNull::getDynamicLightCount()
{
	return Lights.size();
}

//! Returns light data which was previously set with IVideDriver::addDynamicLight().
//! \param idx: Zero based index of the light. Must be greater than 0 and smaller
//! than IVideoDriver()::getDynamicLightCount.
//! \return Light data.
const SLight& CVideoNull::getDynamicLight(s32 idx)
{
	if (idx<0 || idx>=(s32)Lights.size())
		return *((SLight*)0);

	return Lights[idx];
}


//! Creates an 1bit alpha channel of the texture based of an color key.
void CVideoNull::makeColorKeyTexture(video::ITexture* texture, video::SColor color)
{
	if (!texture)
		return;

	if (texture->getColorFormat() != EHCF_R5G5B5)
	{
		os::Warning::print("Could not make color key channel because texture is not R5G5B5.");
		return;
	}

	s16 *p = (s16*)texture->lock();

	if (!p)
	{
		os::Warning::print("Could not lock texture for making color key channel.");
		return;
	}

	core::dimension2d<s32> dim = texture->getDimension();

	s16 ref = (0x0<<15) | (~(0x1<<15) & color.toA1R5G5B5());
	s16 blackalpha = (0x0<<15) | (~(0x1<<15) & 0);

	for (s32 x=0; x<dim.Width; ++x)
		for (s32 y=0; y<dim.Height; ++y)
		{
			s16 c = (0x0<<15) | (~(0x1<<15) & p[y*dim.Width + x]);
			p[y*dim.Width + x] = (c == ref) ? blackalpha : ((0x1<<15) | (~(0x1<<15) & c));
		}

    texture->unlock();
}

//! Creates an 1bit alpha channel of the texture based of an color key position.
void CVideoNull::makeColorKeyTexture(video::ITexture* texture, core::position2d<s32> colorKeyPixelPos)
{
	if (!texture)
		return;

	if (texture->getColorFormat() != EHCF_R5G5B5)
	{
		os::Warning::print("Could not make color key channel because texture is not R5G5B5.");
		return;
	}

	s16 *p = (s16*)texture->lock();

	if (!p)
	{
		os::Warning::print("Could not lock texture for making color key channel.");
		return;
	}

	core::dimension2d<s32> dim = texture->getDimension();
	s32 pitch = texture->getPitch() / 2;

	s16 ref = (0x0<<15) | (~(0x1<<15) & p[colorKeyPixelPos.Y*dim.Width + colorKeyPixelPos.X]);
	s16 blackalpha = (0x0<<15) | (~(0x1<<15) & 0);

	for (s32 x=0; x<pitch; ++x)
		for (s32 y=0; y<dim.Height; ++y)
		{
			s16 c = (0x0<<15) | (~(0x1<<15) & p[y*pitch + x]);
			p[y*pitch + x] = (c == ref) ? blackalpha : ((0x1<<15) | (~(0x1<<15) & c));
		}

    texture->unlock();
}




//! creates a video driver
IVideoDriver* createNullDriver(io::IFileSystem* io, const core::dimension2d<s32>& screenSize)
{
	return new CVideoNull(io, screenSize);
}


} // end namespace
} // end namespace

