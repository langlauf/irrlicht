// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "os.h"
#include <stdio.h>


#ifdef WIN32

	// ----------------------------------------------------------------
	// Windows specific functions
	// ----------------------------------------------------------------

#include <windows.h>

namespace irr
{
namespace os
{


	//! prints a debuginfo string
	void Debuginfo::print(const c8* message, const c8* hint)
	{
		size_t hs = hint ? strlen(hint) : 0;
		c8* tmp = new c8[strlen(message) + hs + 14];
		sprintf(tmp, "%s%s%s\n", message, hint ? ":" : " ", hint ? hint : " ");
		OutputDebugString(tmp);
		delete [] tmp;
	}

	//! prints a debuginfo string (unicode)
	void Debuginfo::print(const wchar_t* message, const wchar_t* hint)
	{
		size_t hs = hint ? wcslen(hint) : 0;
		wchar_t* tmp = new wchar_t[wcslen(message) + hs + 14];
		swprintf(tmp, L"%s%s%s\n", message, hint ? L":" : L" ", hint ? hint : L" ");
		OutputDebugStringW(tmp);
		delete [] tmp;
	}

	//! prints a debuginfo string
	void Debuginfo::print(const c8* message, s32 number)
	{
		char* tmp = new char[strlen(message) + 20];
		sprintf(tmp, "%s: %d\n", message, number);
		OutputDebugString(tmp);
		delete [] tmp;
	}

	//! shows a warning message box
	void Warning::show(const c8* warning, const c8* hint)
	{
		if (hint)
		{
			c8* tmp = new c8[strlen(warning) + strlen(hint) + 2];
			sprintf(tmp, "%s\n%s", warning, hint);
			MessageBoxA(0, tmp, "Warning!", MB_OK);
			delete [] tmp;
		}
		else
			MessageBox(0, warning, "Warning!", MB_OK);	
	}



	//! shows a warning message box in unicode form
	void Warning::show(const wchar_t* warning, const wchar_t* hint)
	{
		if (hint)
		{
			wchar_t* tmp = new wchar_t[wcslen(warning) + wcslen(hint) + 2];
			swprintf(tmp, L"%s\n%s", warning, hint);
			MessageBoxW(0, tmp, L"Warning!", MB_OK);
			delete [] tmp;
		}
		else
			MessageBoxW(0, warning, L"Warning!", MB_OK);	
	}



	//! prints a warning into the warning log
	void Warning::print(const c8* message, const c8* hint)
	{
		size_t hs = hint ? strlen(hint) : 0;
		c8* tmp = new c8[strlen(message) + hs + 14];
		sprintf(tmp, "Warning: %s%s%s\n", message, hint ? ":" : " ", hint ? hint : " ");
		OutputDebugString(tmp);
		delete [] tmp;
	}

	LARGE_INTEGER HighPerformanceFreq;
	BOOL HighPerformanceTimerSupport = FALSE;

	void Timer::initTimer()
	{
		HighPerformanceTimerSupport = QueryPerformanceFrequency(&HighPerformanceFreq);
	}

    u32 Timer::getTime()
	{
		if (HighPerformanceTimerSupport)
		{
			LARGE_INTEGER nTime;
			QueryPerformanceCounter(&nTime);
			return u32((nTime.QuadPart) * 1000 / HighPerformanceFreq.QuadPart);
		}

		return GetTickCount();
	}

} // end namespace os


#else

	// ----------------------------------------------------------------
	// linux/ansi version
	// ----------------------------------------------------------------

#include <stdio.h>
#include <time.h>
#include <sys/time.h>

namespace irr
{
namespace os
{


	//! prints a debuginfo string
	void Debuginfo::print(const c8* message, const c8* hint)
	{
		printf("%s%s%s\n", message, hint ? ":" : " ", hint ? hint : " ");
	}

		//! prints a debuginfo string
	void Debuginfo::print(const c8* message, s32 number)
	{
		printf("%s: %d\n", message, number);
	}

	//! prints a debuginfo string (unicode)
	void Debuginfo::print(const wchar_t* message, const wchar_t* hint)
	{
	  // TODO: where is wprintf?
	  //wprintf(L"%s%s%s\n", message, hint ? L":" : L" ", hint ? hint : L" ");
	}

	//! shows a warning message box
	void Warning::show(const c8* message, const c8* hint)
	{
		// TODO: display message box
		printf("Warning: %s%s%s\n", message, hint ? ":" : " ", hint ? hint : " ");
	}



	//! shows a warning message box in unicode form
	void Warning::show(const wchar_t* message, const wchar_t* hint)
	{
		// TODO: display message box
		//wprintf(L"Warning: %s%s%s\n", message, hint ? L":" : L" ", hint ? hint : L" ");
	}


	//! prints a warning into the warning log
	void Warning::print(const c8* message, const c8* hint)
	{
		printf("Warning: %s%s%s\n", message, hint ? ":" : " ", hint ? hint : " ");
	}

	void Timer::initTimer()
	{
	}

	
	u32 Timer::getTime()
	{
		static timeval tv;
		//static timezone tz;
		gettimeofday(&tv, 0);
		return (u32)tv.tv_usec / 1000;
	}

} // end namespace os



#endif



namespace os
{
	// our Randomizer is not really os specific, so we
	// code one for all, which should work on every platform the same,
	// which is desireable.

	s32 Randomizer::seed = 0x0f0f0f0f;

	//! generates a pseudo random number
	s32 Randomizer::rand()
	{
		const s32 m = 2147483399;	// a non-Mersenne prime
		const s32 a = 40692;		// another spectral success story
		const s32 q = 52774;		// m/a
		const s32 r = 3791;			// m%a; again less than q

		seed = a * (seed%q) - r* (seed/q);
		if (seed<0) seed += m;

		return seed;
	}

	//! resets the randomizer
	void Randomizer::reset()
	{
		seed = 0x0f0f0f0f;
	}

} // end namespace os
} // end namespace irr

