// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#ifndef __C_VIDEO_OPEN_GL_H_INCLUDED__
#define __C_VIDEO_OPEN_GL_H_INCLUDED__

#include "CVideoNull.h"

#ifdef WIN32
// include windows headers for HWND
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <gl\gl.h>
#include <gl\glu.h>
#pragma comment(lib, "OpenGL32.lib")
#pragma comment(lib, "GLu32.lib")
#endif

#include "IrrCompileConfig.h"
#ifdef _IRR_COMPILE_WITH_OPENGL_

#include "glext.h"

namespace irr
{
namespace video
{
	class CVideoOpenGL : public CVideoNull
	{
	public:

		#ifdef WIN32
		//! win32 constructor
		CVideoOpenGL(const core::dimension2d<s32>& screenSize, HWND window, bool fullscreen, io::IFileSystem* io);

		//! inits the open gl driver
		bool initDriver(const core::dimension2d<s32>& screenSize, HWND window, bool fullscreen);
		#endif

		//! destructor
		virtual ~CVideoOpenGL();

		//! presents the rendered scene on the screen, returns false if failed
		virtual bool endScene();

		//! clears the zbuffer
		virtual bool beginScene(bool backBuffer, bool zBuffer, SColor color);

		//! sets transformation
		virtual void setTransform(E_TRANSFORMATION_STATE state, const core::matrix4& mat);

		//! draws an indexed triangle list
		virtual void drawIndexedTriangleList(const S3DVertex* vertices, s32 vertexCount, const u16* indexList, s32 triangleCount);

		//! draws an indexed triangle list
		virtual void drawIndexedTriangleList(const S3DVertex2TCoords* vertices, s32 vertexCount, const u16* indexList, s32 triangleCount);

		//! queries the features of the driver, returns true if feature is available
		bool queryFeature(EK3D_VIDEO_DRIVER_FEATURE feature);

		//! Sets a material. All 3d drawing functions draw geometry now
		//! using this material.
		//! \param material: Material to be used from now on.
		virtual void setMaterial(const SMaterial& material);

		//! draws an 2d image
		virtual void draw2DImage(video::ITexture* texture, const core::position2d<s32>& destPos);

		//! draws an 2d image, using a color (if color is other then Color(255,255,255,255)) and the alpha channel of the texture if wanted.
		virtual void draw2DImage(video::ITexture* texture, const core::position2d<s32>& destPos,
			const core::rectEx<s32>& sourceRect, const core::rectEx<s32>* clipRect = 0, 
			SColor color=SColor(255,255,255,255), bool useAlphaChannelOfTexture=false);

		//! draw an 2d rectangle
		virtual void draw2DRectangle(SColor color, const core::rectEx<s32>& pos, 
			const core::rectEx<s32>* clip = 0);

		//! \return Returns the name of the video driver. Example: In case of the DirectX8
		//! driver, it would return "Direct3D8.1".
		virtual const wchar_t* getName();

		//! deletes all dynamic lights there are
		virtual void deleteAllDynamicLights();

		//! adds a dynamic light
		virtual void addDynamicLight(const SLight& light);

		//! returns the maximal amount of dynamic lights the device can handle
		virtual s32 getMaximalDynamicLightAmount();

		//! Sets the dynamic ambient light color. The default color is
		//! (0,0,0,0) which means it is dark.
		//! \param color: New color of the ambient light.
		virtual void setAmbientLight(const SColorf& color);

	private:

		//! returns a device dependent texture from a software surface (ISurface)
		//! THIS METHOD HAS TO BE OVERRIDDEN BY DERIVED DRIVERS WITH OWN TEXTURES
		virtual video::ITexture* createDeviceDependentTexture(ISurface* surface, bool generateMipLevels);

		inline void createGLMatrix(GLfloat gl_matrix[16], const core::matrix4& m)
		{
			s32 i = 0;
			for (s32 r=0; r<4; ++r)
				for (s32 c=0; c<4; ++c)
					gl_matrix[i++] = m(c,r);
		}

		//! sets the needed renderstates
		void setRenderStates3DMode();

		//! sets the needed renderstates
		void setRenderStates2DMode(bool alpha, bool texture, bool alphaChannel);

		//! sets the current Texture
		void setTexture(s32 stage, video::ITexture* texture);

		//! prints error if an error happened.
		void printGLError();

		void loadExtensions();

		core::matrix4 Matrizes[TS_COUNT];
		core::array<s32> ColorBuffer;

		#ifdef WIN32		
		HDC HDc; // Private GDI Device Context
		HWND Window;
		#endif

		HGLRC HRc; // Permanent Rendering Context

		// enumeration for rendering modes such as 2d and 3d for minizing the switching of renderStates.
		enum E_RENDER_MODE
		{
			ERM_NONE = 0,	// no render state has been set yet.
			ERM_2D,			// 2d drawing rendermode
			ERM_3D			// 3d rendering mode
		};

		E_RENDER_MODE CurrentRenderMode;
		bool ResetRenderStates; // bool to make all renderstates be reseted if set.
		bool Transformation3DChanged;
		bool MultiTextureExtension;
		bool ClampTexture;

		SMaterial Material, LastMaterial;
		s32 LastSetLight;	

		GLint MaxTextureUnits;

		PFNGLACTIVETEXTUREARBPROC	glActiveTextureARB;
		PFNGLCLIENTACTIVETEXTUREARBPROC	glClientActiveTextureARB;
	};

} // end namespace video
} // end namespace irr


#endif // _IRR_COMPILE_WITH_OPENGL_
#endif

