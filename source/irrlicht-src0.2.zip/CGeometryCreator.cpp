// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CGeometryCreator.h"
#include "SAnimatedMesh.h"
#include "SMeshBuffer.h"
#include "SMesh.h"

namespace irr
{
namespace scene
{

// creates a hill plane
IAnimatedMesh* CGeometryCreator::createHillPlaneMesh(const core::dimension2d<f32>& tileSize, const core::dimension2d<s32>& tileCount,
	video::SMaterial* material,	f32 hillHeight, core::dimension2d<f32> countHills)
{
	SMeshBuffer* buffer = new SMeshBuffer();
	SMesh* mesh = new SMesh();
	video::S3DVertex vtx;
	vtx.Color.set(255,255,255,255);
	vtx.Normal.set(0,1,0);

	if (countHills.Width < 0.01f) countHills.Width = 1;
	if (countHills.Height < 0.01f) countHills.Height = 1;

	float halfX = (tileSize.Width * tileCount.Width) / 2;
	float halfY = (tileSize.Height * tileCount.Height) / 2;

	// create vertices

	s32 x = 0;
	s32 y = 0;

	for (x=0; x<tileCount.Width; ++x)
		for (y=0; y<tileCount.Height; ++y)
		{
			vtx.Pos.set(tileSize.Width * x - halfX, 0, tileSize.Height * y - halfY);
			vtx.TCoords.set(-(f32)x / tileCount.Width, (f32)y / tileCount.Height);
			
			if (hillHeight)
				vtx.Pos.Y = (f32)(sin(vtx.Pos.X * countHills.Width * irr::core::PI / halfX) *
					cos(vtx.Pos.Z * countHills.Height * irr::core::PI / halfY))
					*hillHeight;

			buffer->Vertices.push_back(vtx);
		}

	// create indices

	for (x=0; x<tileCount.Width-1; ++x)
		for (y=0; y<tileCount.Height-1; ++y)
		{
			s32 current = y*tileCount.Width + x;

			buffer->Indices.push_back(current);
			buffer->Indices.push_back(current + 1);
			buffer->Indices.push_back(current + tileCount.Width);

			buffer->Indices.push_back(current + 1);
			buffer->Indices.push_back(current + 1 + tileCount.Width);
			buffer->Indices.push_back(current + tileCount.Width);
		}

	if (material)
		buffer->Material = *material;

	SAnimatedMesh* animatedMesh = new SAnimatedMesh();
	mesh->addMeshBuffer(buffer);
	animatedMesh->addMesh(mesh);

	mesh->drop();
	buffer->drop();

	return animatedMesh;
}


} // end namespace scene
} // end namespace irr
