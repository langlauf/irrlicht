// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#ifndef __C_GEOMETRY_CREATOR_H_INCLUDED__
#define __C_GEOMETRY_CREATOR_H_INCLUDED__

#include "IAnimatedMesh.h"

namespace irr
{
namespace scene
{

//! class for creating geometry on the fly
class CGeometryCreator
{
public:

	static IAnimatedMesh* createHillPlaneMesh(
		const core::dimension2d<f32>& tileSize, const core::dimension2d<s32>& tileCount,
		video::SMaterial* material,	f32 hillHeight, core::dimension2d<f32> countHills);
};


} // end namespace scene
} // end namespace irr

#endif

