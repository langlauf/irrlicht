// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#include "CSceneNodeAnimatorFlyCircle.h"

namespace irr
{
namespace scene
{

//! constructor
CSceneNodeAnimatorFlyCircle::CSceneNodeAnimatorFlyCircle(u32 time, const core::vector3df& normal, f32 radius, f32 speed)
: Radius(radius), Normal(normal), Speed(speed), StartTime(time)
{
	#ifdef _DEBUG
	setDebugName("CSceneNodeAnimatorFlyCircle");
	#endif
}



//! destructor
CSceneNodeAnimatorFlyCircle::~CSceneNodeAnimatorFlyCircle()
{
}



//! animates a scene node
void CSceneNodeAnimatorFlyCircle::animateNode(ISceneNode* node, u32 timeMs)
{
	core::matrix4 mat;

	f32 t = (timeMs-StartTime) * Speed;

	mat.setTranslation(core::vector3df( (f32)(Radius * sin(t)), 0, (f32)(Radius * cos(t))));

	// TODO: den errechneten punkt kippen, und zwar mit der normalen.

	node->getAnimatedRelativeTransformation() *= mat;
}


} // end namespace scene
} // end namespace irr

