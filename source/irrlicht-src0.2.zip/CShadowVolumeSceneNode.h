// Copyright (C) 2002-2003 Nikolaus Gebhardt
// This file is part of the "Irrlicht Engine".
// For conditions of distribution and use, see copyright notice in Irrlicht.h

#ifndef __C_SHADOW_VOLUME_SCENE_NODE_H_INCLUDED__
#define __C_SHADOW_VOLUME_SCENE_NODE_H_INCLUDED__

#include "IShadowVolumeSceneNode.H"
#include "SLight.h"

namespace irr
{
namespace scene
{

	//! Scene node for rendering a shadow volume into a stencil buffer.
	class CShadowVolumeSceneNode : public IShadowVolumeSceneNode
	{
	public:

		//! constructor
		CShadowVolumeSceneNode(ISceneNode* parent, ISceneManager* mgr, s32 id);

		//! destructor
		virtual ~CShadowVolumeSceneNode();

		//! sets the mesh from which the shadow volume should be generated.
		virtual void setMeshToRenderFrom(IMesh* mesh);

		//! pre render method
		virtual void OnPreRender();

		//! renders the node.
		virtual void render();

		//! returns the axis aligned bounding box of this node
		virtual const core::aabbox3d<f32>& getBoundingBox() const;

		//! returns the material based on the zero based index i.
		virtual video::SMaterial& getMaterial(s32 i);
		
		//! returns amount of materials used by this scene node.
		virtual s32 getMaterialCount();

	private:

		struct SShadowVolume
		{
			core::vector3df* vertices;
			s32 count;
			s32 size;
		};

		void createShadowVolume(const core::vector3df& pos);
		void addEdge(s32& numEdges, u16 v0, u16 v1);

		core::aabbox3d<f32> Box;

		u16* Indices;
		core::vector3df* Vertices;

		s32 IndexCountAllocated;
		s32 VertexCountAllocated;
		s32 IndexCount;
		s32 VertexCount;
		

		core::array<SShadowVolume> ShadowVolumes;
		s32 ShadowVolumesUsed;

		u16* Edges;
		s32 EdgeCount;
	};

} // end namespace scene
} // end namespace irr

#endif

